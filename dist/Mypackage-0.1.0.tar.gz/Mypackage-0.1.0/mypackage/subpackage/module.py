import numpy as np
from mypackage.main import Gen
class summarize(Gen):
       def __init__ (self,size,nameDist,**kwargs):
              super().__init__(size,nameDist,**kwargs)
          
       def draw_sample(self):
             import matplotlib.pyplot as plt
             Gen.check_par()
             s=Gen.sample()
             count,bins,ignored=plt.hist(s,self.par[2], density=True)
             return plt.show()
     
       def descriptive_sample(self):
             Gen.check_par()
             s=Gen.sample()
             out_s=np.array([np.min(s),np.max(s),np.mean(s),np.std(s)])
             return out_s,print("Descriptive Method for"+ nameDist + " Distribution:","\n",'min:',np.min(s),'max:',np.max(s),'mean:',np.mean(s),'std:',np.std(s))



